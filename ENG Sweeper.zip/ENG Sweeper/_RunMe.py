# Mikhail Andrenkov
# Winter 2014 McMaster Python Game Challenge
# _RunMe Module (ENG Sweeper "Executable" File)

import VarData, EndGame
import Menu

# Initiates Game, Commence the Journey!
def main():
    Menu.MenuMain(True, True) # Opening Screen , New Window

# Just in Case...
if __name__ == "__main__":
    main()